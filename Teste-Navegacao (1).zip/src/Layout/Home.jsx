import Cabecalho from './Cabecalho.jsx'
import Corpo from './Corpo.jsx'

export default function Home() {
  return (
    <>
      <Cabecalho />
      <Corpo />
    </>
  );
};