import { combineReducers } from 'redux';
import carrosSlice from './carros/carrosSlice';
import horariosSlice from "./horarios/horariosSlice";

// Importar os outros reducers

const rootReducer = combineReducers({
  carros: carrosSlice,
  horarios: horariosSlice,
  // Adicionar outros reducers aqui
});

export default rootReducer;