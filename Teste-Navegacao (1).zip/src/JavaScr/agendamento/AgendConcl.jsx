import Cabecalho from '../../Layout/Cabecalho.jsx'
import '/bootstrap-5.3.1-dist/css/bootstrap.css'

export default function AgendConcl() {
  return (
    <>
      <Cabecalho />
      <div className='container'>
        <div className='row'>
          <div className="col text-center">
            <br></br>
            <h2>Agendamento Concluído!</h2>
            <br></br>
            <h3>Em breve entraremos em contato</h3>
          </div>
        </div>

      </div>


    </>
  )
}

