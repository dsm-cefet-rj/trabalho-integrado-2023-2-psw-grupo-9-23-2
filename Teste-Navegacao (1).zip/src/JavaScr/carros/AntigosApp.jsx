import Cabecalho from '../../Layout/Cabecalho.jsx'
import CardCarro from './CardCarro.jsx'
import Formulario from '../../Layout/Formulario.jsx'
import '/bootstrap-5.3.1-dist/css/bootstrap.css'
import carrosData from '../../json/Seminovos.json'

export default function AntigosApp() {
  return (
    <>
      <Cabecalho /> 
      <h2>Escolha o carro de sua preferência:</h2>
      <hr mt-3></hr>
      <Formulario />
      <hr mt-3></hr>
        <main className="flex-fill">
          <div className="container">
            <div className="row g-3">
              {carrosData.map((carro, index) => (
            <CardCarro key={index} {...carro} />))}
            </div>
          </div>
        </main>
    </>
  );
};