import Cabecalho from '../../Layout/Cabecalho.jsx'
import CardCarro from './CardCarro.jsx'
import Formulario from '../../Layout/Formulario.jsx'
import '/bootstrap-5.3.1-dist/css/bootstrap.css'
import CarrosData from '../../json/Carros.json'
import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux';
import rootReducer from '../redux/rootReducer.js'; // Importe a ação fetchCarros


export default function AntigosApp() {

  const [listaCarros, setListaCarros] = useState([]);
    const getlistaCarros = async () => {
        const response = await fetch(
            "http://localhost:8000/carros"
        ).then((response) => response.json());
        setListasCarros(response);
    }



  
  
  const [buscaNome, setBuscaNome] = useState('');
  const [buscaMarca, setBuscaMarca] = useState('');
  const [buscaValor, setBuscaValor] = useState('');
  const [buscaKm, setBuscaKm] = useState('');
  
  const lowerBusca = buscaNome.toLowerCase();
  
  const carrosFiltrados = carrosData.filter(
    (carro) => carro.isAntigo === true &&
    carro.nome.toLowerCase().includes(lowerBusca) &&
    (buscaMarca != "" ? buscaMarca.includes(carro.marca) : carro.marca)&&
    (buscaValor != "" ? parseInt(carro.valor) <= parseInt(buscaValor) : carro.valor) &&  
    (buscaKm != "" ? parseInt(carro.km) <= parseInt(buscaKm) : carro.km)   
  );

  const dispatch = useDispatch();
   function handleClick() {
        const novoCarro = {
          id: Math.random(), // Gere um ID único
          nome: 'Novo Carro',
          km: 0,
          marca: 'Marca',
          valor: 0,
          isAntigo: true,
          };
       dispatch(rootReducer());
    }
  
  return (
    <>
      <Cabecalho />
      <button onClick={handleClick}>Clique-me</button>
      <h2>Escolha o carro de sua preferência:</h2>
      <hr mt-3></hr>
      <Formulario 
        buscaNome={buscaNome} setBuscaNome={setBuscaNome}
         buscaMarca ={buscaMarca}  setBuscaMarca = {setBuscaMarca}
        buscaValor = {buscaValor} setBuscaValor = {setBuscaValor}
        buscaKm = {buscaKm} setBuscaKm = {setBuscaKm}
        />
      <hr mt-3></hr>
      <main className="flex-fill">
        <div className="container">
          <div className="row g-3">
            {carrosFiltrados.map((carro, index) => (
              <CardCarro key={index} {...carro}  />))}
          </div>
        </div>
      </main>
    </>
  );
};

